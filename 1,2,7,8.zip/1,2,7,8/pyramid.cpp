#include "BoardGame_Classes.h"
#include <algorithm>
#include <limits>

/////////////////////////////////////////////////////////////
// Pyramid Tic-Tac-Toe Board Implementation
/////////////////////////////////////////////////////////////

template <typename T>
class PyramidBoard : public Board<T> {
private:
    // Valid positions in pyramid (row, col pairs)
    // Row 0: positions 1,2,3,4,5 (base)
    // Row 1: positions 1,2,3 (middle)
    // Row 2: position 1 (top)

    bool is_valid_position(int x, int y) {
        if (x < 0 || x >= this->rows || y < 0 || y >= this->columns)
            return false;

        // Row 0 (base): columns 0-4 are valid
        if (x == 0 && y >= 0 && y <= 4) return true;
        // Row 1 (middle): columns 1-3 are valid
        if (x == 1 && y >= 1 && y <= 3) return true;
        // Row 2 (top): column 2 is valid
        if (x == 2 && y == 2) return true;

        return false;
    }

public:
    PyramidBoard() : Board<T>(3, 5) {
        // Initialize all cells to empty space
        for (int i = 0; i < this->rows; i++) {
            for (int j = 0; j < this->columns; j++) {
                this->board[i][j] = ' ';
            }
        }
    }

    bool update_board(Move<T>* move) override {
        int x = move->get_x();
        int y = move->get_y();
        T symbol = move->get_symbol();

        if (!is_valid_position(x, y)) {
            cout << "Invalid position! Not part of the pyramid.\n";
            return false;
        }

        if (this->board[x][y] != ' ') {
            cout << "This cell is already occupied!\n";
            return false;
        }

        this->board[x][y] = symbol;
        this->n_moves++;
        return true;
    }

    bool is_win(Player<T>* player) override {
        T symbol = player->get_symbol();

        // Check horizontal lines
        // Base row (row 0)
        for (int j = 0; j <= 2; j++) {
            if (this->board[0][j] == symbol &&
                this->board[0][j+1] == symbol &&
                this->board[0][j+2] == symbol)
                return true;
        }

        // Middle row (row 1)
        if (this->board[1][1] == symbol &&
            this->board[1][2] == symbol &&
            this->board[1][3] == symbol)
            return true;

        // Check vertical lines
        // Left column
        if (this->board[0][0] == symbol &&
            this->board[1][1] == symbol &&
            this->board[2][2] == symbol)
            return true;

        // Middle-left column
        if (this->board[0][1] == symbol &&
            this->board[1][1] == symbol &&
            this->board[2][2] == symbol)
            return true;

        // Center column
        if (this->board[0][2] == symbol &&
            this->board[1][2] == symbol &&
            this->board[2][2] == symbol)
            return true;

        // Middle-right column
        if (this->board[0][3] == symbol &&
            this->board[1][3] == symbol &&
            this->board[2][2] == symbol)
            return true;

        // Right column
        if (this->board[0][4] == symbol &&
            this->board[1][3] == symbol &&
            this->board[2][2] == symbol)
            return true;

        // Check diagonals (left to right)
        if (this->board[0][0] == symbol &&
            this->board[1][2] == symbol &&
            this->board[2][2] == symbol)
            return true;

        if (this->board[0][1] == symbol &&
            this->board[1][2] == symbol &&
            this->board[0][3] == symbol)
            return true;

        if (this->board[0][2] == symbol &&
            this->board[1][3] == symbol &&
            this->board[2][2] == symbol)
            return true;

        // Check diagonals (right to left)
        if (this->board[0][4] == symbol &&
            this->board[1][2] == symbol &&
            this->board[2][2] == symbol)
            return true;

        if (this->board[0][3] == symbol &&
            this->board[1][2] == symbol &&
            this->board[0][1] == symbol)
            return true;

        if (this->board[0][2] == symbol &&
            this->board[1][1] == symbol &&
            this->board[2][2] == symbol)
            return true;

        return false;
    }

    bool is_lose(Player<T>* player) override {
        return false; // Not used in this game
    }

    bool is_draw(Player<T>* player) override {
        // Total valid cells in pyramid: 5 + 3 + 1 = 9
        if (this->n_moves >= 9 && !is_win(player)) {
            return true;
        }
        return false;
    }

    bool game_is_over(Player<T>* player) override {
        return is_win(player) || is_draw(player);
    }
};

/////////////////////////////////////////////////////////////
// Human Player Implementation
/////////////////////////////////////////////////////////////

template <typename T>
class PyramidHumanPlayer : public Player<T> {
public:
    PyramidHumanPlayer(string name, T symbol)
        : Player<T>(name, symbol, PlayerType::HUMAN) {}
};

/////////////////////////////////////////////////////////////
// Computer Player Implementation (Random moves)
/////////////////////////////////////////////////////////////

template <typename T>
class PyramidComputerPlayer : public Player<T> {
private:
    vector<pair<int,int>> get_valid_moves() {
        vector<pair<int,int>> valid_moves;
        auto board_matrix = this->boardPtr->get_board_matrix();

        // Check all valid pyramid positions
        vector<pair<int,int>> positions = {
            {0,0}, {0,1}, {0,2}, {0,3}, {0,4},  // Base row
            {1,1}, {1,2}, {1,3},                 // Middle row
            {2,2}                                // Top
        };

        for (auto& pos : positions) {
            if (board_matrix[pos.first][pos.second] == ' ') {
                valid_moves.push_back(pos);
            }
        }

        return valid_moves;
    }

public:
    PyramidComputerPlayer(string name, T symbol)
        : Player<T>(name, symbol, PlayerType::COMPUTER) {}

    pair<int,int> get_random_move() {
        vector<pair<int,int>> valid_moves = get_valid_moves();
        if (valid_moves.empty()) {
            return {-1, -1};
        }
        int random_index = rand() % valid_moves.size();
        return valid_moves[random_index];
    }
};

/////////////////////////////////////////////////////////////
// UI Implementation
/////////////////////////////////////////////////////////////

template <typename T>
class PyramidUI : public UI<T> {
public:
    PyramidUI() : UI<T>("=== Pyramid Tic-Tac-Toe ===", 3) {}

    void display_pyramid(const vector<vector<T>>& matrix) const {
        if (matrix.empty()) return;

        cout << "\n";
        cout << "=================================\n";
        cout << "     PYRAMID TIC-TAC-TOE\n";
        cout << "=================================\n\n";

        // Top of pyramid
        cout << "           [2,2]\n";
        cout << "             " << matrix[2][2] << "\n";
        cout << "            / \\\n\n";

        // Middle row
        cout << "       [1,1][1,2][1,3]\n";
        cout << "         " << matrix[1][1] << "   " << matrix[1][2] << "   " << matrix[1][3] << "\n";
        cout << "        / \\ / \\ / \\\n\n";

        // Base row
        cout << "  [0,0][0,1][0,2][0,3][0,4]\n";
        cout << "    " << matrix[0][0] << "   " << matrix[0][1] << "   "
             << matrix[0][2] << "   " << matrix[0][3] << "   " << matrix[0][4] << "\n\n";

        cout << "---------------------------------\n";
        cout << "Valid positions:\n";
        cout << "  Top:    Row 2, Col 2\n";
        cout << "  Middle: Row 1, Cols 1-3\n";
        cout << "  Base:   Row 0, Cols 0-4\n";
        cout << "=================================\n\n";
    }

    Move<T>* get_move(Player<T>* player) override {
        cout << player->get_name() << "'s turn (" << player->get_symbol() << ")\n";

        int x, y;

        if (player->get_type() == PlayerType::COMPUTER) {
            PyramidComputerPlayer<T>* comp = dynamic_cast<PyramidComputerPlayer<T>*>(player);
            auto move = comp->get_random_move();
            x = move.first;
            y = move.second;
            cout << "Computer chooses: Row " << x << ", Column " << y << "\n";
        } else {
            cout << "Enter row (0-2): ";
            cin >> x;
            cout << "Enter column (0-4): ";
            cin >> y;
        }

        return new Move<T>(x, y, player->get_symbol());
    }

    Player<T>* create_player(string& name, T symbol, PlayerType type) override {
        if (type == PlayerType::COMPUTER) {
            return new PyramidComputerPlayer<T>(name, symbol);
        } else {
            return new PyramidHumanPlayer<T>(name, symbol);
        }
    }

};

/////////////////////////////////////////////////////////////
// Custom Game Manager for Pyramid
/////////////////////////////////////////////////////////////

template <typename T>
class PyramidGameManager {
    Board<T>* boardPtr;
    Player<T>* players[2];
    PyramidUI<T>* ui;

public:
    PyramidGameManager(Board<T>* b, Player<T>* p[2], PyramidUI<T>* u)
        : boardPtr(b), ui(u) {
        players[0] = p[0];
        players[1] = p[1];
        players[0]->set_board_ptr(b);
        players[1]->set_board_ptr(b);
    }

    void run() {
        ui->display_pyramid(boardPtr->get_board_matrix());
        Player<T>* currentPlayer = players[0];

        while (true) {
            for (int i : {0, 1}) {
                currentPlayer = players[i];
                Move<T>* move = ui->get_move(currentPlayer);

                while (!boardPtr->update_board(move)) {
                    delete move;
                    move = ui->get_move(currentPlayer);
                }

                ui->display_pyramid(boardPtr->get_board_matrix());

                if (boardPtr->is_win(currentPlayer)) {
                    ui->display_message(currentPlayer->get_name() + " wins!");
                    delete move;
                    return;
                }
                if (boardPtr->is_lose(currentPlayer)) {
                    ui->display_message(players[1 - i]->get_name() + " wins!");
                    delete move;
                    return;
                }
                if (boardPtr->is_draw(currentPlayer)) {
                    ui->display_message("Draw!");
                    delete move;
                    return;
                }

                delete move;
            }
        }
    }
};

/////////////////////////////////////////////////////////////
// Main Function
/////////////////////////////////////////////////////////////

int main() {
    srand(time(0));

    // Create game components
    PyramidBoard<char>* board = new PyramidBoard<char>();
    PyramidUI<char>* ui = new PyramidUI<char>();

    // Setup players
    Player<char>** players = ui->setup_players();

    // Create and run game with custom manager
    PyramidGameManager<char> game(board, players, ui);
    game.run();

    // Cleanup
    delete board;
    delete ui;
    delete players[0];
    delete players[1];
    delete[] players;

    return 0;
}