#ifndef SUS_BOARD_H
#define SUS_BOARD_H

#include "BoardGame_Classes.h"

class SUS_Board : public Board<char> {
private:
    char blank_symbol = ' ';
    int player1_score = 0;
    int player2_score = 0;

    int countSUSSequences();
    void updateScores();

public:
    SUS_Board();
    bool update_board(Move<char>* move) override;
    bool is_win(Player<char>* player) override;
    bool is_draw(Player<char>* player) override;
    bool game_is_over(Player<char>* player) override;
    bool is_lose(Player<char>* player) override { return false; }

    // Getters for scores
    int get_player1_score() const { return player1_score; }
    int get_player2_score() const { return player2_score; }
};

#endif