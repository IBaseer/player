#include "SUS_UI.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

SUS_UI::SUS_UI() : UI("=== SUS Game ===", 3) {
    srand(time(0));
}

Player<char>* SUS_UI::create_player(string& name, char symbol, PlayerType type) {
    cout << "Creating " << (type == PlayerType::HUMAN ? "human" : "computer")
         << " player: " << name << " (" << symbol << ")\n";
    return new Player<char>(name, symbol, type);
}

Move<char>* SUS_UI::get_move(Player<char>* player) {
    int x, y;

    if (player->get_type() == PlayerType::HUMAN) {
        cout << player->get_name() << " (" << player->get_symbol() << "), enter your move (row col 0-2): ";
        cin >> x >> y;
    } else {
        // Computer player - random move
        x = rand() % 3;
        y = rand() % 3;
        cout << player->get_name() << " (computer) plays at (" << x << "," << y << ")\n";
    }

    return new Move<char>(x, y, player->get_symbol());
}