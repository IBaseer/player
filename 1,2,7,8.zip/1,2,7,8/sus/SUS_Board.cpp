#include "SUS_Board.h"
#include <iostream>
#include <cctype>
using namespace std;

// Constructor
SUS_Board::SUS_Board() : Board(3, 3) {
    player1_score = 0;
    player2_score = 0;

    // Initialize board with blank symbols
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            board[i][j] = blank_symbol;
        }
    }
}

bool SUS_Board::update_board(Move<char>* move) {
    if (!move) {
        return false;
    }

    int x = move->get_x();
    int y = move->get_y();
    char symbol = move->get_symbol();

    // Validate move
    if (x < 0 || x >= 3 || y < 0 || y >= 3) {
        return false;
    }

    if (board[x][y] != blank_symbol) {
        return false;
    }

    // Apply move
    board[x][y] = toupper(symbol);
    n_moves++;

    // Update scores
    updateScores();

    return true;
}

int SUS_Board::countSUSSequences() {
    int count = 0;

    // Check all possible S-U-S sequences
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            // Horizontal S-U-S (left to right)
            if (j <= 1) {
                if (board[i][j] == 'S' && board[i][j+1] == 'U' && board[i][j+2] == 'S') {
                    count++;
                }
            }

            // Vertical S-U-S (top to bottom)
            if (i <= 1) {
                if (board[i][j] == 'S' && board[i+1][j] == 'U' && board[i+2][j] == 'S') {
                    count++;
                }
            }

            // Diagonal \ S-U-S
            if (i <= 1 && j <= 1) {
                if (board[i][j] == 'S' && board[i+1][j+1] == 'U' && board[i+2][j+2] == 'S') {
                    count++;
                }
            }

            // Diagonal / S-U-S
            if (i <= 1 && j >= 1) {
                if (board[i][j] == 'S' && board[i+1][j-1] == 'U' && board[i+2][j-2] == 'S') {
                    count++;
                }
            }
        }
    }

    return count;
}

void SUS_Board::updateScores() {
    // Reset scores
    player1_score = 0;
    player2_score = 0;

    int totalSequences = countSUSSequences();

    // Simple scoring: All sequences go to Player 2 (U)
    player2_score = totalSequences;
}

bool SUS_Board::is_win(Player<char>* player) {
    // Only check winner when board is full
    if (n_moves < 9) return false;

    char player_symbol = player->get_symbol();

    if (player_symbol == 'S') {
        return player1_score > player2_score;
    } else {
        return player2_score > player1_score;
    }
}

bool SUS_Board::is_draw(Player<char>* player) {
    return (n_moves == 9 && player1_score == player2_score);
}

bool SUS_Board::game_is_over(Player<char>* player) {
    return (n_moves == 9);
}