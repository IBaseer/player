#include "SUS_Board.h"
#include <iostream>
#include <limits>
using namespace std;

class SimpleSUSUI {
public:
    Move<char>* get_move(char symbol) {
        int x, y;
        cout << "Player " << symbol << ", enter your move (row col 0-2): ";
        cin >> x >> y;
        return new Move<char>(x, y, symbol);
    }

    void display_board(SUS_Board& board) {
        cout << "\n  0 1 2\n";
        auto matrix = board.get_board_matrix();
        for (int i = 0; i < 3; i++) {
            cout << i << " ";
            for (int j = 0; j < 3; j++) {
                cout << (matrix[i][j] == ' ' ? '.' : matrix[i][j]) << " ";
            }
            cout << endl;
        }

        // Display scores
        cout << "Scores - P1(S): " << board.get_player1_score()
             << "  P2(U): " << board.get_player2_score() << endl;
        cout << "Moves: " << count_moves(matrix) << "/9" << endl;
    }

private:
    int count_moves(const vector<vector<char>>& matrix) {
        int count = 0;
        for (const auto& row : matrix) {
            for (char cell : row) {
                if (cell != ' ') count++;
            }
        }
        return count;
    }
};

int main() {
    cout << "=== SUS Game - Complete Version ===" << endl;
    cout << "Rules: Create S-U-S sequences. Game ends when board is full." << endl;
    cout << "Player 1: S, Player 2: U" << endl << endl;

    SUS_Board board;
    SimpleSUSUI ui;
    char current_symbol = 'S';

    while (!board.game_is_over(nullptr)) {
        ui.display_board(board);

        Move<char>* move = ui.get_move(current_symbol);

        if (board.update_board(move)) {
            // Switch player only if move was successful
            current_symbol = (current_symbol == 'S') ? 'U' : 'S';
        } else {
            cout << "Invalid move! Try again." << endl;
        }

        delete move;
    }

    // Final display with results - FIXED MEMORY ISSUE
    ui.display_board(board);
    cout << "\n=== GAME OVER ===" << endl;
    cout << "Final Scores:" << endl;
    cout << "Player 1 (S): " << board.get_player1_score() << " points" << endl;
    cout << "Player 2 (U): " << board.get_player2_score() << " points" << endl;

    // Determine winner WITHOUT creating temporary Player objects
    if (board.get_player1_score() > board.get_player2_score()) {
        cout << "Player 1 (S) wins!" << endl;
    } else if (board.get_player2_score() > board.get_player1_score()) {
        cout << "Player 2 (U) wins!" << endl;
    } else {
        cout << "It's a draw!" << endl;
    }

    cout << "\nPress Enter to exit...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();

    return 0;
}