#ifndef _TICTACTOE4X4_H
#define _TICTACTOE4X4_H

#include "BoardGame_Classes.h"
#include <vector>
#include <utility>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

/**
 * @brief Move class for 4x4 Tic-Tac-Toe
 */
class TicTacToe4x4Move : public Move<char> {
private:
    int from_x, from_y;  // Starting position for the move
    int to_x, to_y;      // Target position for the move

public:
    TicTacToe4x4Move(int from_x, int from_y, int to_x, int to_y, char symbol)
        : Move<char>(to_x, to_y, symbol), from_x(from_x), from_y(from_y), to_x(to_x), to_y(to_y) {}

    int get_from_x() const { return from_x; }
    int get_from_y() const { return from_y; }
    int get_to_x() const { return to_x; }
    int get_to_y() const { return to_y; }
};

/**
 * @brief Board class for 4x4 Tic-Tac-Toe
 */
class TicTacToe4x4Board : public Board<char> {
private:
    vector<pair<int, int>> x_tokens;  // Positions of X tokens
    vector<pair<int, int>> o_tokens;  // Positions of O tokens

    bool is_adjacent(int from_x, int from_y, int to_x, int to_y) const {
        int dx = abs(from_x - to_x);
        int dy = abs(from_y - to_y);
        return (dx == 1 && dy == 0) || (dx == 0 && dy == 1);
    }

    bool is_three_in_line(const vector<pair<int, int>>& positions) const {
        if (positions.size() < 3) return false;

        // Check all combinations of three tokens
        for (size_t i = 0; i < positions.size(); ++i) {
            for (size_t j = i + 1; j < positions.size(); ++j) {
                for (size_t k = j + 1; k < positions.size(); ++k) {
                    int x1 = positions[i].first, y1 = positions[i].second;
                    int x2 = positions[j].first, y2 = positions[j].second;
                    int x3 = positions[k].first, y3 = positions[k].second;

                    // Check row
                    if (x1 == x2 && x2 == x3) {
                        vector<int> ys = {y1, y2, y3};
                        sort(ys.begin(), ys.end());
                        if (ys[2] - ys[0] == 2) return true;
                    }
                    // Check column
                    else if (y1 == y2 && y2 == y3) {
                        vector<int> xs = {x1, x2, x3};
                        sort(xs.begin(), xs.end());
                        if (xs[2] - xs[0] == 2) return true;
                    }
                    // Check diagonal (main)
                    else if (x1 - y1 == x2 - y2 && x2 - y2 == x3 - y3) {
                        vector<int> xs = {x1, x2, x3};
                        sort(xs.begin(), xs.end());
                        if (xs[2] - xs[0] == 2) return true;
                    }
                    // Check diagonal (anti)
                    else if (x1 + y1 == x2 + y2 && x2 + y2 == x3 + y3) {
                        vector<int> xs = {x1, x2, x3};
                        sort(xs.begin(), xs.end());
                        if (xs[2] - xs[0] == 2) return true;
                    }
                }
            }
        }
        return false;
    }

public:
    TicTacToe4x4Board() : Board<char>(4, 4) {
        // Initialize with checkerboard pattern based on your image
        x_tokens = {{0, 1}, {0, 3}, {3, 0}, {3, 2}};  // X positions
        o_tokens = {{0, 0}, {0, 2}, {3, 1}, {3, 3}};  // O positions

        // Clear the board first
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 4; ++j) {
                board[i][j] = 0;
            }
        }

        // Update the board representation with X tokens
        for (const auto& pos : x_tokens) {
            board[pos.first][pos.second] = 'X';
        }
        // Update the board representation with O tokens
        for (const auto& pos : o_tokens) {
            board[pos.first][pos.second] = 'O';
        }
    }

    bool update_board(Move<char>* move_ptr) override {
        TicTacToe4x4Move* move = static_cast<TicTacToe4x4Move*>(move_ptr);

        int from_x = move->get_from_x();
        int from_y = move->get_from_y();
        int to_x = move->get_to_x();
        int to_y = move->get_to_y();
        char symbol = move->get_symbol();

        // Check bounds
        if (from_x < 0 || from_x >= 4 || from_y < 0 || from_y >= 4 ||
            to_x < 0 || to_x >= 4 || to_y < 0 || to_y >= 4) {
            cout << "Error: Position out of bounds!" << endl;
            return false;
        }

        // Check if FROM position contains the player's token
        char from_symbol = board[from_x][from_y];
        if (from_symbol != symbol) {
            cout << "Error: No " << symbol << " token at position (" << from_x << "," << from_y << ")!" << endl;
            return false;
        }

        // Check if target position is empty
        if (board[to_x][to_y] != 0) {
            cout << "Error: Target position (" << to_x << "," << to_y << ") is not empty!" << endl;
            return false;
        }

        // Check if move is adjacent
        if (!is_adjacent(from_x, from_y, to_x, to_y)) {
            cout << "Error: Can only move to adjacent positions (up, down, left, right)!" << endl;
            return false;
        }

        // Execute the move
        board[from_x][from_y] = 0;
        board[to_x][to_y] = symbol;

        // Update token positions
        vector<pair<int, int>>* tokens = (symbol == 'X') ? &x_tokens : &o_tokens;
        for (auto& pos : *tokens) {
            if (pos.first == from_x && pos.second == from_y) {
                pos.first = to_x;
                pos.second = to_y;
                break;
            }
        }

        n_moves++;
        cout << "Move successful! " << symbol << " moved from (" << from_x << "," << from_y
             << ") to (" << to_x << "," << to_y << ")" << endl;
        return true;
    }

    bool is_win(Player<char>* player) override {
        char symbol = player->get_symbol();
        if (symbol == 'X') {
            return is_three_in_line(x_tokens);
        } else if (symbol == 'O') {
            return is_three_in_line(o_tokens);
        }
        return false;
    }

    bool is_lose(Player<char>* player) override {
        char symbol = player->get_symbol();
        if (symbol == 'X') {
            return is_three_in_line(o_tokens);
        } else if (symbol == 'O') {
            return is_three_in_line(x_tokens);
        }
        return false;
    }

    bool is_draw(Player<char>* player) override {
        return n_moves >= 50;
    }

    bool game_is_over(Player<char>* player) override {
        return is_win(player) || is_lose(player) || is_draw(player);
    }

    const vector<pair<int, int>>& get_x_tokens() const { return x_tokens; }
    const vector<pair<int, int>>& get_o_tokens() const { return o_tokens; }
};

/**
 * @brief Player class for 4x4 Tic-Tac-Toe
 */
class TicTacToe4x4Player : public Player<char> {
public:
    TicTacToe4x4Player(string name, char symbol, PlayerType type)
        : Player<char>(name, symbol, type) {}
};

/**
 * @brief UI class for 4x4 Tic-Tac-Toe
 */
class TicTacToe4x4UI : public UI<char> {
public:
    TicTacToe4x4UI() : UI<char>("=== 4x4 Tic-Tac-Toe ===", 3) {}

    Move<char>* get_move(Player<char>* player) override {
        TicTacToe4x4Board* board = dynamic_cast<TicTacToe4x4Board*>(player->get_board_ptr());
        if (!board) return nullptr;

        char symbol = player->get_symbol();

        if (player->get_type() == PlayerType::HUMAN) {
            int from_x, from_y, to_x, to_y;

            cout << player->get_name() << " (" << symbol << "), enter your move:" << endl;
            cout << "Enter FROM position (x y): ";
            cin >> from_x >> from_y;

            cout << "Enter TO position (x y): ";
            cin >> to_x >> to_y;

            return new TicTacToe4x4Move(from_x, from_y, to_x, to_y, symbol);
        } else {
            // Simple computer AI
            const vector<pair<int, int>>& tokens = (symbol == 'X') ?
                board->get_x_tokens() : board->get_o_tokens();

            // Try to find a valid move
            for (int attempt = 0; attempt < 100; ++attempt) {
                int token_idx = rand() % tokens.size();
                int from_x = tokens[token_idx].first;
                int from_y = tokens[token_idx].second;

                vector<pair<int, int>> directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
                for (const auto& dir : directions) {
                    int to_x = from_x + dir.first;
                    int to_y = from_y + dir.second;

                    if (to_x >= 0 && to_x < 4 && to_y >= 0 && to_y < 4) {
                        // Check if target is empty using the board matrix
                        auto board_matrix = board->get_board_matrix();
                        if (board_matrix[to_x][to_y] == 0) {
                            return new TicTacToe4x4Move(from_x, from_y, to_x, to_y, symbol);
                        }
                    }
                }
            }

            // Fallback
            return new TicTacToe4x4Move(0, 0, 1, 0, symbol);
        }
    }

    Player<char>* create_player(string& name, char symbol, PlayerType type) override {
        return new TicTacToe4x4Player(name, symbol, type);
    }
};

#endif // _TICTACTOE4X4_H