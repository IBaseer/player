#include "TicTacToe4x4.h"
#include <cstdlib>
#include <ctime>

int main() {
    srand(time(0));

    TicTacToe4x4UI* ui = new TicTacToe4x4UI();
    Player<char>** players = ui->setup_players();
    TicTacToe4x4Board* board = new TicTacToe4x4Board();
    GameManager<char> gameManager(board, players, ui);

    gameManager.run();

    delete players[0];
    delete players[1];
    delete[] players;
    delete board;
    delete ui;

    return 0;
}