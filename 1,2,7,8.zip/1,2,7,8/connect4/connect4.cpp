// connect4.cpp
#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <random>
#include <chrono>
#include <limits>
#include <memory>
#include <sstream>

enum class PlayerType { HUMAN, COMPUTER, AI, RANDOM };

template <typename T>
class Move {
    int x_;
    int y_;
    T symbol_;
public:
    Move(int x = -1, int y = -1, T s = T()) : x_(x), y_(y), symbol_(s) {}
    int get_x() const { return x_; }
    int get_y() const { return y_; }
    T get_symbol() const { return symbol_; }
};

template <typename T>
class Board {
protected:
    int rows_;
    int cols_;
    std::vector<std::vector<T>> mat_;
    int n_moves_ = 0;
    T empty_symbol_;
public:
    Board(int rows, int cols, T empty_symbol)
        : rows_(rows), cols_(cols), mat_(rows, std::vector<T>(cols, empty_symbol)),
          empty_symbol_(empty_symbol) {}
    virtual ~Board() = default;

    virtual bool update_board(const Move<T>& move) = 0;
    virtual bool is_win(const T& symbol) const = 0;
    virtual bool is_draw() const { return n_moves_ >= rows_ * cols_; }

    std::vector<std::vector<T>> get_board_matrix() const { return mat_; }
    int get_rows() const { return rows_; }
    int get_columns() const { return cols_; }
    T get_empty_symbol() const { return empty_symbol_; }
    int get_n_moves() const { return n_moves_; }
protected:
    void increment_moves() { ++n_moves_; }
};

class Connect4Board : public Board<char> {
public:
    Connect4Board(int rows = 6, int cols = 7, char empty_symbol = ' ')
        : Board<char>(rows, cols, empty_symbol) {}

    // Place piece in lowest available row of column move.get_y()
    bool update_board(const Move<char>& move) override {
        int col = move.get_y();
        if (col < 0 || col >= get_columns()) return false;
        for (int r = get_rows() - 1; r >= 0; --r) {
            if (mat_[r][col] == get_empty_symbol()) {
                mat_[r][col] = move.get_symbol();
                increment_moves();
                return true;
            }
        }
        return false; // column full
    }

    bool is_win(const char& s) const override {
        const int R = get_rows();
        const int C = get_columns();
        auto &b = mat_;
        auto in_bounds = [&](int r, int c){ return r >= 0 && r < R && c >= 0 && c < C; };
        const int dr[4] = {0, 1, 1, 1};
        const int dc[4] = {1, 0, 1, -1};

        for (int r = 0; r < R; ++r) {
            for (int c = 0; c < C; ++c) {
                if (b[r][c] != s) continue;
                for (int d = 0; d < 4; ++d) {
                    int cnt = 0;
                    for (int k = 0; k < 4; ++k) {
                        int rr = r + k * dr[d];
                        int cc = c + k * dc[d];
                        if (!in_bounds(rr, cc) || b[rr][cc] != s) break;
                        ++cnt;
                    }
                    if (cnt == 4) return true;
                }
            }
        }
        return false;
    }
};

template <typename T>
class Player {
protected:
    std::string name_;
    PlayerType type_;
    T symbol_;
    Board<T>* boardPtr_ = nullptr;
public:
    Player(const std::string& name, T symbol, PlayerType type)
        : name_(name), type_(type), symbol_(symbol) {}
    virtual ~Player() = default;
    std::string get_name() const { return name_; }
    PlayerType get_type() const { return type_; }
    T get_symbol() const { return symbol_; }
    void set_board_ptr(Board<T>* b) { boardPtr_ = b; }
    Board<T>* get_board_ptr() const { return boardPtr_; }

    // For AI players override this to produce a move
    virtual Move<T> get_move() { return Move<T>(); }
};

class HumanPlayer : public Player<char> {
public:
    HumanPlayer(const std::string& name, char symbol)
        : Player<char>(name, symbol, PlayerType::HUMAN) {}
    Move<char> get_move() override { return Move<char>(); } // not used directly
};

class RandomAIPlayer : public Player<char> {
    std::mt19937 rng_;
public:
    RandomAIPlayer(const std::string& name, char symbol)
        : Player<char>(name, symbol, PlayerType::RANDOM),
          rng_(static_cast<unsigned>(std::chrono::high_resolution_clock::now().time_since_epoch().count())) {}

    Move<char> get_move() override {
        Board<char>* b = get_board_ptr();
        int cols = b->get_columns();
        std::vector<int> valid;
        auto mat = b->get_board_matrix();
        for (int c = 0; c < cols; ++c) {
            if (mat[0][c] == b->get_empty_symbol()) valid.push_back(c);
        }
        if (valid.empty()) return Move<char>(-1, -1, get_symbol());
        std::uniform_int_distribution<int> dist(0, static_cast<int>(valid.size()) - 1);
        int col = valid[dist(rng_)];
        return Move<char>(-1, col, get_symbol());
    }
};

class ConsoleUI {
    int cell_width_;
public:
    ConsoleUI(int cell_width = 1) : cell_width_(cell_width) {}

    void display_board(const Board<char>* b) const {
        auto matrix = b->get_board_matrix();
        int rows = matrix.size();
        int cols = matrix[0].size();
        std::cout << "\n    ";
        for (int j = 0; j < cols; ++j) std::cout << std::setw(3) << j;
        std::cout << "\n   " << std::string(4 * cols + 1, '-') << "\n";
        for (int i = 0; i < rows; ++i) {
            std::cout << std::setw(2) << i << " |";
            for (int j = 0; j < cols; ++j) {
                std::cout << std::setw(2) << matrix[i][j] << " |";
            }
            std::cout << "\n   " << std::string(4 * cols + 1, '-') << "\n";
        }
        std::cout << std::endl;
    }

    // Read a single integer from a line of input; returns false on EOF
    static bool read_int_from_line(int &out, int minv, int maxv, const std::string &prompt) {
        std::string line;
        while (true) {
            std::cout << prompt << std::flush;
            if (!std::getline(std::cin, line)) return false; // EOF or error
            std::istringstream iss(line);
            if (!(iss >> out)) {
                std::cout << "Invalid input. Enter a number.\n";
                continue;
            }
            if (out < minv || out > maxv) {
                std::cout << "Out of range. Enter a number between " << minv << " and " << maxv << ".\n";
                continue;
            }
            return true;
        }
    }

    Move<char> get_move(Player<char>* p) {
        if (p->get_type() == PlayerType::HUMAN) {
            Board<char>* b = p->get_board_ptr();
            int maxcol = b->get_columns() - 1;
            int col;
            std::string prompt = p->get_name() + " (" + p->get_symbol() + ") choose column [0-" + std::to_string(maxcol) + "]: ";
            if (!read_int_from_line(col, 0, maxcol, prompt)) {
                // EOF or error: return invalid move
                return Move<char>(-1, -1, p->get_symbol());
            }
            return Move<char>(-1, col, p->get_symbol());
        } else {
            return p->get_move();
        }
    }

    void display_message(const std::string& msg) const {
        std::cout << msg << std::endl;
    }
};

class GameManager {
    Connect4Board board_;
    std::unique_ptr<Player<char>> players_[2];
    ConsoleUI ui_;
public:
    GameManager(std::unique_ptr<Player<char>> p0, std::unique_ptr<Player<char>> p1)
        : board_(6, 7, ' '), ui_(1) {
        players_[0] = std::move(p0);
        players_[1] = std::move(p1);
        players_[0]->set_board_ptr(&board_);
        players_[1]->set_board_ptr(&board_);
    }

    void run() {
        ui_.display_board(&board_);
        int turn = 0;
        while (true) {
            Player<char>* cur = players_[turn].get();
            Move<char> move = ui_.get_move(cur);

            if (!board_.update_board(move)) {
                ui_.display_message("Invalid move. Column full or out of range. Try again.");
                continue;
            }

            ui_.display_board(&board_);

            if (board_.is_win(cur->get_symbol())) {
                ui_.display_message(cur->get_name() + " wins!");
                return;
            }
            if (board_.is_draw()) {
                ui_.display_message("Draw!");
                return;
            }
            turn = 1 - turn;
        }
    }
};

static bool read_choice_line(int &out, int minv, int maxv, const std::string &prompt) {
    std::string line;
    while (true) {
        std::cout << prompt << std::flush;
        if (!std::getline(std::cin, line)) return false;
        std::istringstream iss(line);
        if (!(iss >> out)) {
            std::cout << "Invalid input. Enter a number.\n";
            continue;
        }
        if (out < minv || out > maxv) {
            std::cout << "Out of range. Enter a number between " << minv << " and " << maxv << ".\n";
            continue;
        }
        return true;
    }
}

int main() {
    std::cout << "Connect Four 6x7\n";
    int choice = 0;
    if (!read_choice_line(choice, 1, 2, "Choose mode:\n1. Human vs Human\n2. Human vs Random AI\nEnter choice: ")) {
        return 0;
    }

    std::unique_ptr<Player<char>> p1;
    std::unique_ptr<Player<char>> p2;

    std::string name1, name2;
    if (choice == 1) {
        std::cout << "Enter name for Player X: " << std::flush;
        if (!std::getline(std::cin, name1)) return 0;
        if (name1.empty()) name1 = "PlayerX";
        std::cout << "Enter name for Player O: " << std::flush;
        if (!std::getline(std::cin, name2)) return 0;
        if (name2.empty()) name2 = "PlayerO";
        p1 = std::make_unique<HumanPlayer>(name1, 'X');
        p2 = std::make_unique<HumanPlayer>(name2, 'O');
    } else {
        std::cout << "Enter your name (you will be X): " << std::flush;
        if (!std::getline(std::cin, name1)) return 0;
        if (name1.empty()) name1 = "PlayerX";
        p1 = std::make_unique<HumanPlayer>(name1, 'X');
        p2 = std::make_unique<RandomAIPlayer>("CPU", 'O');
    }

    GameManager gm(std::move(p1), std::move(p2));
    gm.run();
    return 0;
}